%%
%% %CopyrightBegin%
%%
%% Copyright Ericsson AB 1996-2024. All Rights Reserved.
%%
%% Licensed under the Apache License, Version 2.0 (the "License");
%% you may not use this file except in compliance with the License.
%% You may obtain a copy of the License at
%%
%%     http://www.apache.org/licenses/LICENSE-2.0
%%
%% Unless required by applicable law or agreed to in writing, software
%% distributed under the License is distributed on an "AS IS" BASIS,
%% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
%% See the License for the specific language governing permissions and
%% limitations under the License.
%%
%% %CopyrightEnd%
%%
{application, sasl,
   [{description, "SASL  CXC 138 11"},
    {vsn, "4.2.2"},
    {modules, [sasl, 
	       alarm_handler, 
               format_lib_supp, 
               misc_supp, 
               rb, 
               rb_format_supp, 
	       release_handler, 
	       release_handler_1, 
	       erlsrv,
	       sasl_report, 
	       sasl_report_tty_h, 
	       sasl_report_file_h, 
	       systools, 
	       systools_make, 
	       systools_rc, 
	       systools_relup, 
	       systools_lib
	      ]},
    {registered, [sasl_sup, alarm_handler, release_handler]},
    {applications, [kernel, stdlib]},
    {env, []},
    {mod, {sasl, []}},
    {runtime_dependencies, ["tools-2.6.14","stdlib-4.0","kernel-6.0",
			    "erts-15.0"]}]}.

